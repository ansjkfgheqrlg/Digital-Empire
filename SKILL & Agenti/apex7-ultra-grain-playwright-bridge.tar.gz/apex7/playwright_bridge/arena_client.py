"""
APEX-7 Arena Playwright Client - Bridge per Claude Code
Permette a Claude Code (che non può generare immagini) di controllare Arena.ai via browser automation

Install: pip install playwright && playwright install chromium
"""

import asyncio
import os
import json
import time
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import yaml
import base64

try:
    from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    print("[WARN] playwright non installato - userai fallback locale con generate_image")

BASE_DIR = Path(__file__).parent.parent
CONFIG_PATH = BASE_DIR / "playwright_bridge" / "config.yaml"
OUTPUT_DIR = BASE_DIR / "outputs" / "carousel"

class ArenaPlaywrightClient:
    def __init__(self, config_path: Path = CONFIG_PATH, headless: bool = True, model: str = "GPT-4o"):
        self.config = self._load_config(config_path)
        self.headless = headless
        self.model = model
        self.browser = None
        self.page = None
        self.playwright = None
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        print(f"[ARENA PLAYWRIGHT] Init model={model} headless={headless} playwright_available={PLAYWRIGHT_AVAILABLE}")

    def _load_config(self, path: Path):
        if path.exists():
            return yaml.safe_load(path.read_text(encoding='utf-8'))
        return {
            "arena": {
                "url": "https://arena.ai",
                "selectors": {
                    "prompt_input": ['textarea'],
                    "generate_button": ['button[type=\"submit\"]'],
                    "generated_images": ['img']
                }
            }
        }

    async def start(self):
        if not PLAYWRIGHT_AVAILABLE:
            print("[ARENA CLIENT] Playwright non disponibile - modalità fallback locale attiva")
            return False
        
        self.playwright = await async_playwright().start()
        browser_type = getattr(self.playwright, self.config.get("playwright", {}).get("browser", "chromium"))
        self.browser = await browser_type.launch(
            headless=self.headless,
            args=self.config.get("playwright", {}).get("args", ["--no-sandbox"])
        )
        context = await self.browser.new_context(
            viewport=self.config.get("playwright", {}).get("viewport", {"width": 1920, "height": 1080}),
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
        )
        self.page = await context.new_page()
        
        # Vai su Arena
        url = self.config["arena"]["url"]
        print(f"[ARENA] Navigating to {url}")
        try:
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await self.page.wait_for_timeout(3000)
            print(f"[ARENA] Loaded: {await self.page.title()}")
            return True
        except Exception as e:
            print(f"[ARENA] Load error {e}, trying fallback")
            for fb_url in self.config["arena"].get("fallback_urls", []):
                try:
                    await self.page.goto(fb_url, timeout=20000)
                    await self.page.wait_for_timeout(2000)
                    print(f"[ARENA] Fallback loaded: {fb_url}")
                    return True
                except:
                    continue
            return False

    async def close(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

    async def _find_element(self, selector_list: List[str], timeout: int = 10000):
        """Trova elemento provando lista selettori con fallback"""
        for sel in selector_list:
            try:
                elem = self.page.locator(sel).first
                await elem.wait_for(state="visible", timeout=timeout//len(selector_list))
                print(f"[FINDER] Found with selector: {sel}")
                return elem
            except:
                continue
        return None

    async def _select_model(self, model_name: str):
        """Seleziona modello GPT-4o / Claude 3.5 su Arena"""
        selectors = self.config["arena"]["selectors"].get("model_selector", [])
        elem = await self._find_element(selectors, timeout=5000)
        if elem:
            try:
                await elem.click(timeout=5000)
                await self.page.wait_for_timeout(1000)
                # Cerca opzione modello
                model_option = self.page.locator(f"text={model_name}").first
                if await model_option.count() > 0:
                    await model_option.click()
                    print(f"[ARENA] Model selected: {model_name}")
                    await self.page.wait_for_timeout(1000)
            except Exception as e:
                print(f"[ARENA] Model select warning: {e}")
        else:
            print(f"[ARENA] Model selector not found, using default {model_name}")

    async def generate_image(self, prompt: str, output_path: Path, slide_num: int = 1) -> Dict:
        """
        Genera singola immagine su Arena via Playwright
        Se Playwright non disponibile o fallisce, usa fallback locale (simulazione con enhanced prompt)
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if not PLAYWRIGHT_AVAILABLE or not self.page:
            print(f"[FALLBACK] Playwright non attivo - salvo prompt per generazione locale futura - Slide {slide_num}")
            # Salva prompt ultra qualità per generazione successiva con tool locale
            meta = {
                "slide": slide_num,
                "prompt": prompt,
                "output_path": str(output_path),
                "model": self.model,
                "timestamp": datetime.now().isoformat(),
                "requires_arena_generation": True,
                "enhanced": "ULTRA GRAIN + 4K SHARP"
            }
            (output_path.with_suffix('.json')).write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
            # Salva anche prompt txt
            (output_path.with_suffix('.txt')).write_text(prompt, encoding='utf-8')
            return {"status": "prompt_saved", "path": str(output_path), "mode": "fallback_local", "slide": slide_num}

        try:
            # Seleziona modello se primo giro
            if slide_num == 1:
                await self._select_model(self.model)

            # Trova input
            input_selectors = self.config["arena"]["selectors"]["prompt_input"]
            input_elem = await self._find_element(input_selectors, timeout=15000)
            
            if not input_elem:
                print(f"[ARENA] Prompt input not found - saving prompt fallback")
                raise Exception("Prompt input not found - fallback")

            # Pulisci e inserisci prompt ultra qualità
            await input_elem.click()
            await self.page.keyboard.press("Control+A")
            await self.page.keyboard.press("Backspace")
            await input_elem.fill(prompt)
            await self.page.wait_for_timeout(500)

            # Trova e clicca genera
            gen_selectors = self.config["arena"]["selectors"]["generate_button"]
            gen_elem = await self._find_element(gen_selectors, timeout=10000)
            
            if gen_elem:
                await gen_elem.click()
                print(f"[ARENA] Generate clicked for slide {slide_num}")
            else:
                # Prova Enter
                await self.page.keyboard.press("Enter")
                print(f"[ARENA] Generate via Enter key slide {slide_num}")

            # Attendi generazione - guarda immagini
            await self.page.wait_for_timeout(3000)
            
            # Wait for images with extended timeout
            image_selectors = self.config["arena"]["selectors"]["generated_images"]
            start = time.time()
            timeout_sec = self.config.get("playwright", {}).get("timeout", 60000) / 1000
            
            while time.time() - start < timeout_sec:
                for sel in image_selectors:
                    try:
                        imgs = self.page.locator(sel)
                        count = await imgs.count()
                        if count > 0:
                            # Prendi ultima immagine
                            last_img = imgs.nth(count-1)
                            # Prova a scaricare
                            try:
                                src = await last_img.get_attribute("src")
                                if src:
                                    if src.startswith("data:"):
                                        # Base64 image
                                        header, data = src.split(",", 1)
                                        img_bytes = base64.b64decode(data)
                                        output_path.write_bytes(img_bytes)
                                        print(f"[ARENA] Image saved (base64) {output_path}")
                                        return {"status": "success", "path": str(output_path), "src_type": "base64", "slide": slide_num}
                                    elif src.startswith("http") or src.startswith("blob:"):
                                        # Scarica via request
                                        try:
                                            # Usa page to fetch
                                            response = await self.page.request.get(src) if hasattr(self.page, 'request') else None
                                            # Fallback: screenshot elemento
                                            await last_img.screenshot(path=output_path)
                                            print(f"[ARENA] Image saved (screenshot) {output_path}")
                                            return {"status": "success", "path": str(output_path), "src_type": "screenshot", "slide": slide_num}
                                        except:
                                            await last_img.screenshot(path=output_path)
                                            return {"status": "success", "path": str(output_path), "src_type": "screenshot_fallback", "slide": slide_num}
                            except Exception as e:
                                print(f"[ARENA] Image extraction attempt failed {sel}: {e}")
                                continue
                    except:
                        continue
                await self.page.wait_for_timeout(2000)
                if int(time.time() - start) % 10 == 0:
                    print(f"[ARENA] Waiting image generation... {int(time.time()-start)}s / {int(timeout_sec)}s slide {slide_num}")

            print(f"[ARENA] Timeout waiting image slide {slide_num} - fallback to prompt save")
            raise TimeoutError("Image generation timeout")

        except Exception as e:
            print(f"[ARENA] Generation error slide {slide_num}: {e} - fallback")
            # Salva prompt per rigenerazione manuale/local
            meta = {
                "slide": slide_num,
                "prompt": prompt,
                "error": str(e),
                "output_path": str(output_path),
                "timestamp": datetime.now().isoformat()
            }
            (output_path.with_suffix('.json')).write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
            (output_path.with_suffix('.txt')).write_text(prompt, encoding='utf-8')
            return {"status": "fallback_saved", "path": str(output_path), "error": str(e), "slide": slide_num}

    async def generate_carousel(self, prompts: List[str], output_dir: Path, model: str = "GPT-4o") -> List[Dict]:
        """Genera carosello completo 8 slide"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        started = await self.start()
        if not started and PLAYWRIGHT_AVAILABLE:
            print("[ARENA] Failed to start, fallback mode")

        results = []
        for i, prompt in enumerate(prompts, 1):
            out_path = output_dir / f"slide_{i:02d}.png"
            print(f"\n[CAROUSEL] {i}/{len(prompts)} Generating with {model} -> {out_path}")
            res = await self.generate_image(prompt, out_path, slide_num=i)
            results.append(res)
            # Delay tra generazioni per non spammare
            await asyncio.sleep(2)

        await self.close()
        return results


# CLI test
if __name__ == "__main__":
    async def test_single():
        client = ArenaPlaywrightClient(headless=False, model="GPT-4o")
        test_prompt = """
        Premium Instagram carousel 1080x1350 black #000000 heavy film grain 35% noise texture on ALL elements background cards text buttons, red-orange glow #FF3B1F corners blurred, pill LA VERITÀ eye red, headline "Non hai un problema di idee. Hai un problema di esecuzione." with problema esecuzione red serif italic, 4K ultra sharp, ultra high resolution, grain on every pixel.
        """
        await client.start()
        res = await client.generate_image(test_prompt, OUTPUT_DIR / "test_slide.png", slide_num=1)
        print(res)
        await client.close()

    asyncio.run(test_single())
