#!/usr/bin/env python3
"""
CLI per /inizio-generazione - Entry point per Claude Code

Claude Code user digita: /inizio-generazione
Questo script gestisce flusso conversazionale e genera carosello

Uso diretto:
python -m playwright_bridge.cli --topic "Content Factory per e-commerce"

Uso interattivo (simula comando /inizio-generazione):
python -m playwright_bridge.cli --interactive

Integrazione Claude Code:
- Copia questo file in ~/.claude/commands/ o usa come custom command
- Registra skill in skills/claude-code-bridge/SKILL.md
"""

import argparse
import asyncio
import sys
from pathlib import Path
import json

# Aggiungi parent path
sys.path.insert(0, str(Path(__file__).parent.parent))

from playwright_bridge.carousel_flow import CarouselFlow

BANNER = """
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║   Digital Empire - Content Factory Carousel Generator          ║
║   Comando: /inizio-generazione                                 ║
║   Bridge Playwright per Claude Code (Arena.ai)                 ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
"""

async def run_interactive(model: str = "GPT-4o", headless: bool = True, use_playwright: bool = True):
    print(BANNER)
    print("🎯 Comando /inizio-generazione attivato\n")
    print("Questo workflow collega Claude Code -> Playwright -> Arena.ai")
    print("per generare caroselli 1080x1350 con grana ultra quality su ogni elemento + 4K nitida.\n")
    
    # Step 1: Chiedi argomento
    print("━" * 70)
    print("👋 Ciao! Sono la Content Factory di Digital Empire.")
    print("   Aspetto che tu mi dica l'argomento del carosello...\n")
    topic = input("📌 Argomento (es. 'Content Factory per coach', 'Sistema AI per concessionari'): ").strip()
    
    if not topic:
        print("❌ Argomento vuoto, uso default 'Content Factory per imprenditori'")
        topic = "Content Factory per imprenditori"
    
    print(f"\n✅ Argomento ricevuto: '{topic}'")
    print(f"   Modello: {model} | Playwright: {'attivo' if use_playwright else 'fallback locale'} | Headless: {headless}\n")
    
    flow = CarouselFlow(model=model, headless=headless, use_playwright=use_playwright)
    
    # Step 2-4: Full flow
    report = await flow.run_full_flow(topic, model=model, use_playwright=use_playwright)
    
    # Step 5: Download ready
    print("\n" + "━" * 70)
    print("📦 CAROSELLO PRONTO PER DOWNLOAD")
    print("━" * 70)
    print(f"Topic: {report['topic']}")
    print(f"Slides: {report['total_slides']} x 1080x1350 (4K source 2160x2700 ultra sharp)")
    print(f"Qualità: {report['quality']}")
    print(f"Output dir: {report['output_dir']}")
    print(f"ZIP: {report['zip_path']}")
    print("\nContenuto ZIP:")
    for slide in report['slides']:
        print(f"  - slide_{slide['slide_num']:02d}.png + prompt + copy")
    print(f"\nScarica: {report['zip_path']}")
    print(f"Poi importa su Claude: il workspace contiene tutto in outputs/carousel/\n")
    print("✨ Fatto! Installa questo workspace su Claude Code e lancia /inizio-generazione per generare altri.\n")

async def run_direct(topic: str, model: str = "GPT-4o", headless: bool = True, use_playwright: bool = True, output_dir: Path = None):
    print(BANNER)
    print(f"🎯 /inizio-generazione - Topic: {topic} Model: {model}\n")
    flow = CarouselFlow(model=model, headless=headless, use_playwright=use_playwright)
    report = await flow.run_full_flow(topic, output_dir=output_dir, model=model, use_playwright=use_playwright)
    print(f"\n✅ Done: {report['zip_path']}")
    return report

def main():
    parser = argparse.ArgumentParser(description="Digital Empire - /inizio-generazione carousel generator via Playwright + Arena.ai")
    parser.add_argument("--topic", type=str, help="Argomento carosello (es. 'Content Factory per coach')")
    parser.add_argument("--model", type=str, default="GPT-4o", choices=["GPT-4o", "Claude 3.5 Sonnet"], help="Modello Arena.ai")
    parser.add_argument("--interactive", action="store_true", help="Modalità interattiva - simula /inizio-generazione con attesa argomento")
    parser.add_argument("--headless", action="store_true", default=True, help="Browser headless (default true)")
    parser.add_argument("--no-headless", action="store_true", help="Mostra browser Playwright per debug")
    parser.add_argument("--no-playwright", action="store_true", help="Disabilita Playwright - genera solo prompt (fallback locale)")
    parser.add_argument("--output", type=str, help="Output dir custom")
    
    args = parser.parse_args()
    
    headless = not args.no_headless
    use_playwright = not args.no_playwright
    output_dir = Path(args.output) if args.output else None
    
    if args.interactive or not args.topic:
        asyncio.run(run_interactive(model=args.model, headless=headless, use_playwright=use_playwright))
    else:
        asyncio.run(run_direct(topic=args.topic, model=args.model, headless=headless, use_playwright=use_playwright, output_dir=output_dir))

if __name__ == "__main__":
    main()
